let a = [1,2];
[a[0],a[1]] = [a[1],a[0]];
console.log(a);